﻿using EmpDeviceTracking.ActionFilter;
using EmpDeviceTracking.Models;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;

namespace EmpDeviceTracking.Controllers
{
    [MyActionFilterAttribute]
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            try
            {
                string constr;
                SqlConnection conn;

                constr = @"Server=(localdb)\mssqllocaldb;Database=EmployeeDetails;Trusted_Connection=True;MultipleActiveResultSets=true;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";
                conn = new SqlConnection(constr);

                conn.Open();

                SqlCommand cmd;
                SqlDataReader dreader;

                string sql;
                sql = "select * from EmpProvisionInfo";
                cmd = new SqlCommand(sql, conn);
                dreader = cmd.ExecuteReader();

                List<Employee> employees = [];

                while (dreader.Read())
                {
                    Employee emp = new()
                    {
                        HostName = dreader.GetString(10),
                        EmpID = dreader.GetString(0),
                        EmpName = dreader.GetString(1),
                        Site = dreader.GetString(2),
                        Dept = dreader.GetString(3),
                        Lap = dreader.GetBoolean(4),
                        Charger = dreader.GetBoolean(5),
                        Mouse = dreader.GetBoolean(6),
                        LapBag = dreader.GetBoolean(7),
                        MousePad = dreader.GetBoolean(8),
                        Remarks = dreader.GetString(9)
                    };

                    employees.Add(emp);

                    //employees.Add(new Employee
                    //{
                    //    EmpID = Convert.ToString(dreader.GetValue(0)),
                    //    EmpName = Convert.ToString(dreader.GetValue(1)),
                    //    Site = Convert.ToString(dreader.GetValue(2)),
                    //    Dept = Convert.ToString(dreader.GetValue(3)),
                    //    Lap = Convert.ToBoolean(dreader.GetValue(4)),
                    //    Charger = Convert.ToBoolean(dreader.GetValue(5)),
                    //    Mouse = Convert.ToBoolean(dreader.GetValue(6)),
                    //    LapBag = Convert.ToBoolean(dreader.GetValue(7)),
                    //    MousePad = Convert.ToBoolean(dreader.GetValue(8))
                    //});
                }

                dreader.Close();
                cmd.Dispose();
                conn.Close();

                @ViewBag.employees = employees;
                return View();

            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred while retrieving employee data.";
                return View("Error"); 
            }
            
        }

        public IActionResult NewEntry()
        {

            return View();
        }

    [HttpPost]
    public RedirectToActionResult SubmitNewEntry(string hostname, string empid, string empname, string sitename, string deptname,
    string laptop, string charger, string mouse, string laptopbag, string mousepad, string optionalremark)
        {
            DeleteEntry(empid);
            string constr;
            SqlConnection conn;

            constr = @"Server=(localdb)\mssqllocaldb;Database=EmployeeDetails;Trusted_Connection=True;MultipleActiveResultSets=true;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";
            conn = new SqlConnection(constr);

            conn.Open();

            //SqlCommand cmd;
           
            //SqlDataReader dreader;

            string sql;
            sql = "INSERT INTO EmpProvisionInfo (EmpID, EmpName, Site, Dept, Lap, Charger, Mouse, LapBag, MousePad, Remarks, HostName) VALUES (@empid, @empname, @sitename, @deptname, @laptop, @charger, @mouse, @laptopbag, @mousepad , @remark, @hostname)";
            //cmd = new SqlCommand(sql, conn);
            //cmd.CommandType = CommandType.Text;

            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@empid", empid);
                cmd.Parameters.AddWithValue("@empname", empname);
                cmd.Parameters.AddWithValue("@sitename", sitename);
                cmd.Parameters.AddWithValue("@deptname", deptname);
                cmd.Parameters.AddWithValue("@laptop", laptop=="on"?true:false);
                cmd.Parameters.AddWithValue("@charger", charger == "on" ? true : false);
                cmd.Parameters.AddWithValue("@mouse", mouse == "on" ? true : false);
                cmd.Parameters.AddWithValue("@laptopbag", laptopbag == "on" ? true : false);
                cmd.Parameters.AddWithValue("@mousepad", mousepad == "on" ? true : false);
                cmd.Parameters.AddWithValue("@remark", optionalremark);
                cmd.Parameters.AddWithValue("@hostname",hostname);

                cmd.ExecuteNonQuery();
            }
            
            conn.Close();
            return RedirectToAction("NewEntry");            
        }

        public RedirectToActionResult DeleteEntry(string empid)
        {
            //SqlDataAdapter adapter = new SqlDataAdapter();

            string constr;
            SqlConnection conn;

            constr = @"Server=(localdb)\mssqllocaldb;Database=EmployeeDetails;Trusted_Connection=True;MultipleActiveResultSets=true;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";
            conn = new SqlConnection(constr);

            conn.Open();

            //SqlCommand cmd;

            //SqlDataReader dreader;

            string sql;
            sql = "Delete From EmpProvisionInfo Where EmpID=@empid";
            //cmd = new SqlCommand(sql, conn);
            //cmd.CommandType = CommandType.Text;

            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@empid", empid);
                cmd.ExecuteNonQuery();
            }
            
            conn.Close();
            return RedirectToAction("Index");
        }

        public ActionResult EditEntry(string empid)
        {
            
            //SqlDataAdapter adapter = new SqlDataAdapter();

            string constr;
            SqlConnection conn;

            constr = @"Server=(localdb)\mssqllocaldb;Database=EmployeeDetails;Trusted_Connection=True;MultipleActiveResultSets=true;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";
            conn = new SqlConnection(constr);

            conn.Open();

            SqlCommand cmd;

            SqlDataReader dreader;

            string sql;
            sql = "select * from EmpProvisionInfo where EmpID=@empid";
            cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@empid", empid);

            Employee emp = new Employee();

            dreader = cmd.ExecuteReader();
           while(dreader.Read())
            {
                    emp.HostName = dreader.GetString(10);
                    emp.EmpID = dreader.GetString(0);
                    emp.EmpName = dreader.GetString(1);
                    emp.Site = dreader.GetString(2);
                    emp.Dept = dreader.GetString(3);
                    emp.Lap = dreader.GetBoolean(4);
                    emp.Charger = dreader.GetBoolean(5);
                    emp.Mouse = dreader.GetBoolean(6);
                    emp.LapBag = dreader.GetBoolean(7);
                    emp.MousePad = dreader.GetBoolean(8);
                    emp.Remarks = dreader.GetString(9);
                
              
            }
            //cmd.ExecuteNonQuery();
            //DeleteEntry(empid);

            dreader.Close();
            cmd.Dispose();
            conn.Close();
           
              @ViewBag.emp = emp;

            return View();
        }

        
    }    
}


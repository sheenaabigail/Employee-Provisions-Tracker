function navigateToMain() {
    window.location.href = 'main.html';
}
function navigateToAbout() {
    window.location.href = 'aboutus.html';
}
function navigateToContact() {
    window.location.href = 'contactus.html';
}
function navigateToNewEntry() {
    window.location.href = 'new-entry.html';
}
function navigateToMission() {
    window.location.href = 'mission.html';
}
function navigateToPrice() {
    window.location.href = 'price.html';
}
function navigateToRegister() {
    window.location.href = 'register.html';
}
function navigateToBack() {
    window.location.href = 'main.html';
}
function navigateToHome() {
    window.location.href = 'home.html';
}
function navigateToEntryList() {
    window.location.href = 'entry-list.html';
}
function navigateToEditEntry() {
    window.location.href = 'edit-entry.html';
}
